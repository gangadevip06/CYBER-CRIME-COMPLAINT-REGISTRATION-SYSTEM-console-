package cybercrime.exceptions;

public class CyberCrimeException extends Exception {
    public CyberCrimeException(String message) {
        super(message);
    }
    
    public CyberCrimeException(String message, Throwable cause) {
        super(message, cause);
    }
}