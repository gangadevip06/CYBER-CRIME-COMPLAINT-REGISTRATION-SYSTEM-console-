package cybercrime.models;

import java.util.Date;

public class Officer {
    private String officerId;
    private String name;
    private String badgeNumber;
    private String department;
    private String username;
    private String password;
    private String rank;
    private Date joiningDate;
    private boolean isActive;
    
    public Officer(String officerId, String name, String badgeNumber, 
                   String department, String username, String password, String rank) {
        this.officerId = officerId;
        this.name = name;
        this.badgeNumber = badgeNumber;
        this.department = department;
        this.username = username;
        this.password = password;
        this.rank = rank;
        this.joiningDate = new Date();
        this.isActive = true;
    }
    
    public String getOfficerId() { return officerId; }
    public String getName() { return name; }
    public String getBadgeNumber() { return badgeNumber; }
    public String getDepartment() { return department; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getRank() { return rank; }
    public Date getJoiningDate() { return joiningDate; }
    public boolean isActive() { return isActive; }
    
    public void setActive(boolean active) { this.isActive = active; }
    
    public String toFileString() {
        return officerId + "|" + name + "|" + badgeNumber + "|" + department + "|" + 
               username + "|" + password + "|" + rank + "|" + joiningDate.getTime() + "|" + isActive;
    }
    
    public static Officer fromFileString(String line) {
        String[] parts = line.split("\\|");
        Officer officer = new Officer(parts[0], parts[1], parts[2], parts[3], 
            parts[4], parts[5], parts[6]);
        officer.joiningDate = new Date(Long.parseLong(parts[7]));
        officer.isActive = Boolean.parseBoolean(parts[8]);
        return officer;
    }
    
    @Override
    public String toString() {
        return name + " (Badge: " + badgeNumber + ")";
    }
}