package cybercrime.models;

import java.util.Date;

public class Feedback {
    private String feedbackId;
    private String userId;
    private int rating;
    private String comment;
    private Date submittedDate;
    
    public Feedback(String feedbackId, String userId, int rating, String comment) {
        this.feedbackId = feedbackId;
        this.userId = userId;
        this.rating = rating;
        this.comment = comment;
        this.submittedDate = new Date();
    }
    
    public String getFeedbackId() { return feedbackId; }
    public String getUserId() { return userId; }
    public int getRating() { return rating; }
    public String getComment() { return comment; }
    public Date getSubmittedDate() { return submittedDate; }
    
    public String toFileString() {
        return feedbackId + "|" + userId + "|" + rating + "|" + comment + "|" + submittedDate.getTime();
    }
    
    public static Feedback fromFileString(String line) {
        String[] parts = line.split("\\|");
        Feedback feedback = new Feedback(parts[0], parts[1], 
            Integer.parseInt(parts[2]), parts[3]);
        feedback.submittedDate = new Date(Long.parseLong(parts[4]));
        return feedback;
    }
    
    @Override
    public String toString() {
        return "Rating: " + rating + "/5 - " + comment;
    }
}