package cybercrime.models;

import java.util.Date;

public class Complaint {
    public enum ComplaintType {
        CYBER_BULLYING("Cyber Bullying"),
        ONLINE_FRAUD("Online Fraud"),
        IDENTITY_THEFT("Identity Theft"),
        HACKING("Hacking"),
        PHISHING("Phishing"),
        CYBER_STALKING("Cyber Stalking"),
        OTHER("Other");
        
        private String displayName;
        
        ComplaintType(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() { return displayName; }
    }
    
    public enum Status {
        PENDING("Pending"),
        UNDER_REVIEW("Under Review"),
        INVESTIGATING("Investigating"),
        RESOLVED("Resolved"),
        REJECTED("Rejected");
        
        private String displayName;
        
        Status(String displayName) {
            this.displayName = displayName;
        }
        
        public String getDisplayName() { return displayName; }
    }
    
    private String complaintId;
    private String userId;
    private ComplaintType type;
    private String description;
    private String evidencePath;
    private Status status;
    private Date filedDate;
    private String assignedOfficerId;
    private String resolutionNotes;
    
    public Complaint(String complaintId, String userId, ComplaintType type, 
                     String description, String evidencePath) {
        this.complaintId = complaintId;
        this.userId = userId;
        this.type = type;
        this.description = description;
        this.evidencePath = evidencePath;
        this.status = Status.PENDING;
        this.filedDate = new Date();
        this.assignedOfficerId = null;
        this.resolutionNotes = "";
    }
    
    public String getComplaintId() { return complaintId; }
    public String getUserId() { return userId; }
    public ComplaintType getType() { return type; }
    public String getDescription() { return description; }
    public String getEvidencePath() { return evidencePath; }
    public Status getStatus() { return status; }
    public Date getFiledDate() { return filedDate; }
    public String getAssignedOfficerId() { return assignedOfficerId; }
    public String getResolutionNotes() { return resolutionNotes; }
    
    public void setStatus(Status status) { this.status = status; }
    public void setAssignedOfficerId(String assignedOfficerId) { this.assignedOfficerId = assignedOfficerId; }
    public void setResolutionNotes(String resolutionNotes) { this.resolutionNotes = resolutionNotes; }
    
    public String toFileString() {
        return complaintId + "|" + userId + "|" + type.name() + "|" + description + "|" + 
               (evidencePath != null ? evidencePath : "null") + "|" + status.name() + "|" + 
               filedDate.getTime() + "|" + (assignedOfficerId != null ? assignedOfficerId : "null") + "|" + 
               resolutionNotes;
    }
    
    public static Complaint fromFileString(String line) {
        String[] parts = line.split("\\|");
        Complaint complaint = new Complaint(parts[0], parts[1], 
            ComplaintType.valueOf(parts[2]), parts[3], 
            parts[4].equals("null") ? null : parts[4]);
        complaint.status = Status.valueOf(parts[5]);
        complaint.filedDate = new Date(Long.parseLong(parts[6]));
        complaint.assignedOfficerId = parts[7].equals("null") ? null : parts[7];
        complaint.resolutionNotes = parts[8];
        return complaint;
    }
    
    @Override
    public String toString() {
        return "Complaint #" + complaintId + " | " + type.getDisplayName() + " | " + status.getDisplayName();
    }
}