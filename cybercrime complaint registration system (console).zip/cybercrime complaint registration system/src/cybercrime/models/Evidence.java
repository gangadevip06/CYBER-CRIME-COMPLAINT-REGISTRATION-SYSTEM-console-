package cybercrime.models;

import java.util.Date;

public class Evidence {
    public enum EvidenceType {
        SCREENSHOT("Screenshot", ".png,.jpg,.jpeg"),
        IMAGE(" Image", ".png,.jpg,.jpeg,.gif"),
        DOCUMENT(" Document", ".pdf,.doc,.docx,.txt"),
        VIDEO(" Video", ".mp4,.avi,.mov"),
        AUDIO(" Audio", ".mp3,.wav"),
        EMAIL(" Email", ".eml,.msg"),
        URL(" URL", ".txt"),
        OTHER(" Other", "");
        
        private String displayName;
        private String extensions;
        
        EvidenceType(String displayName, String extensions) {
            this.displayName = displayName;
            this.extensions = extensions;
        }
        
        public String getDisplayName() { return displayName; }
        public String getExtensions() { return extensions; }
    }
    
    private String evidenceId;
    private String complaintId;
    private EvidenceType type;
    private String fileName;
    private String filePath;
    private String description;
    private Date uploadDate;
    private long fileSize;
    
    public Evidence(String evidenceId, String complaintId, EvidenceType type, 
                    String fileName, String filePath, String description, long fileSize) {
        this.evidenceId = evidenceId;
        this.complaintId = complaintId;
        this.type = type;
        this.fileName = fileName;
        this.filePath = filePath;
        this.description = description;
        this.uploadDate = new Date();
        this.fileSize = fileSize;
    }
    
    // Getters
    public String getEvidenceId() { return evidenceId; }
    public String getComplaintId() { return complaintId; }
    public EvidenceType getType() { return type; }
    public String getFileName() { return fileName; }
    public String getFilePath() { return filePath; }
    public String getDescription() { return description; }
    public Date getUploadDate() { return uploadDate; }
    public long getFileSize() { return fileSize; }
    
    public String toFileString() {
        return evidenceId + "|" + complaintId + "|" + type.name() + "|" + fileName + "|" + 
               filePath + "|" + description + "|" + uploadDate.getTime() + "|" + fileSize;
    }
    
    public static Evidence fromFileString(String line) {
        String[] parts = line.split("\\|");
        Evidence evidence = new Evidence(parts[0], parts[1], 
            EvidenceType.valueOf(parts[2]), parts[3], parts[4], parts[5], 
            Long.parseLong(parts[7]));
        evidence.uploadDate = new Date(Long.parseLong(parts[6]));
        return evidence;
    }
    
    public String getFileSizeFormatted() {
        if (fileSize < 1024) return fileSize + " B";
        if (fileSize < 1024 * 1024) return (fileSize / 1024) + " KB";
        if (fileSize < 1024 * 1024 * 1024) return (fileSize / (1024 * 1024)) + " MB";
        return (fileSize / (1024 * 1024 * 1024)) + " GB";
    }
    
    @Override
    public String toString() {
        return type.getDisplayName() + " - " + fileName + " (" + getFileSizeFormatted() + ")";
    }
}