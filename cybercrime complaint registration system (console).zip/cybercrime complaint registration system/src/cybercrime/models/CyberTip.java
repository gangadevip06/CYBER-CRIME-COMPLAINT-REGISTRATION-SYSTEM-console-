package cybercrime.models;

import java.util.Date;

public class CyberTip {
    private String title;
    private String content;
    private String category;
    private Date publishedDate;
    
    public CyberTip(String title, String content, String category) {
        this.title = title;
        this.content = content;
        this.category = category;
        this.publishedDate = new Date();
    }
    
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getCategory() { return category; }
    public Date getPublishedDate() { return publishedDate; }
    
    public String toFileString() {
        return title + "|" + content + "|" + category + "|" + publishedDate.getTime();
    }
    
    public static CyberTip fromFileString(String line) {
        String[] parts = line.split("\\|");
        CyberTip tip = new CyberTip(parts[0], parts[1], parts[2]);
        tip.publishedDate = new Date(Long.parseLong(parts[3]));
        return tip;
    }
    
    @Override
    public String toString() {
        return "\n " + title + "\n   Category: " + category + "\n   " + content + "\n";
    }
}