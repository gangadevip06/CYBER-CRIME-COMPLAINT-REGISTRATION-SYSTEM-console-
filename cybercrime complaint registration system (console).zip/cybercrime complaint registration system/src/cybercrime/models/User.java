package cybercrime.models;

import java.util.Date;

public class User {
    private String userId;
    private String name;
    private String email;
    private String phone;
    private String password;
    private Date registrationDate;
    
    public User(String userId, String name, String email, String phone, String password) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.registrationDate = new Date();
    }
    
    public String getUserId() { return userId; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getPassword() { return password; }
    public Date getRegistrationDate() { return registrationDate; }
    
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String toFileString() {
        return userId + "|" + name + "|" + email + "|" + phone + "|" + password + "|" + registrationDate.getTime();
    }
    
    public static User fromFileString(String line) {
        String[] parts = line.split("\\|");
        User user = new User(parts[0], parts[1], parts[2], parts[3], parts[4]);
        user.registrationDate = new Date(Long.parseLong(parts[5]));
        return user;
    }
    
    @Override
    public String toString() {
        return "User ID: " + userId + " | Name: " + name;
    }
}