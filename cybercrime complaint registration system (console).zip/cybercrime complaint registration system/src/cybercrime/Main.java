package cybercrime;

import cybercrime.exceptions.CyberCrimeException;
import cybercrime.models.*;
import cybercrime.services.*;
import java.util.*;
import java.io.*;

public class Main {
    private static AuthenticationService authService;
    private static ComplaintService complaintService;
    private static FeedbackService feedbackService;
    private static CyberTipService tipService;
    private static StatisticsService statisticsService;
    private static Scanner scanner;
    
    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        
        try {
            FileStorageService storageService = new FileStorageService();
            authService = new AuthenticationService(storageService);
            complaintService = new ComplaintService(storageService);
            feedbackService = new FeedbackService(storageService);
            tipService = new CyberTipService(storageService);
            statisticsService = new StatisticsService(complaintService, feedbackService);
            
            System.out.println("=".repeat(60));
            System.out.println("   CYBERCRIME COMPLAINT REGISTRATION SYSTEM");
            System.out.println("   Protecting Digital India");
            System.out.println("=".repeat(60));
            
            while (true) {
                displayMainMenu();
                int choice = getIntInput("Choose an option: ");
                
                switch (choice) {
                    case 1: registerComplaint(); break;
                    case 2: viewCyberTips(); break;
                    case 3: giveFeedback(); break;
                    case 4: officerLogin(); break;
                    case 5: adminLogin(); break;
                    case 6:
                        System.out.println("\n Thank you for using Cybercrime Complaint Registration System!");
                        System.out.println("Stay safe online! ");
                        scanner.close();
                        return;
                    default: System.out.println(" Invalid option! Please try again.");
                }
            }
        } catch (CyberCrimeException e) {
            System.err.println(" System Error: " + e.getMessage());
        }
    }
    
    private static void displayMainMenu() {
        System.out.println("\n" + "-".repeat(40));
        System.out.println(" MAIN MENU");
        System.out.println("-".repeat(40));
        System.out.println("1.  Register Complaint");
        System.out.println("2.  View Cyber Tips");
        System.out.println("3.  Give Feedback");
        System.out.println("4.  Police Officer Login");
        System.out.println("5.  Admin Login");
        System.out.println("6.  Exit");
    }
    
    private static void registerComplaint() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println(" REGISTER COMPLAINT");
            System.out.println("=".repeat(40));
            
            System.out.print("Enter your User ID (or 'new' to register): ");
            String userIdInput = scanner.nextLine();
            
            User user;
            if (userIdInput.equalsIgnoreCase("new")) {
                user = registerNewUser();
                if (user == null) return;
            } else {
                System.out.print("Enter password: ");
                String password = scanner.nextLine();
                user = authService.loginUser(userIdInput, password);
            }
            
            System.out.println("\n Welcome, " + user.getName() + "!");
            
            System.out.println("\nSelect Complaint Type:");
            Complaint.ComplaintType[] types = Complaint.ComplaintType.values();
            for (int i = 0; i < types.length; i++) {
                System.out.printf("%d. %s\n", i + 1, types[i].getDisplayName());
            }
            
            int typeChoice = getIntInput("Enter choice: ");
            if (typeChoice < 1 || typeChoice > types.length) {
                System.out.println(" Invalid choice!");
                return;
            }
            Complaint.ComplaintType selectedType = types[typeChoice - 1];
            
            System.out.print("\n Describe the incident in detail: ");
            String description = scanner.nextLine();
            
            // Register complaint first
            Complaint complaint = complaintService.registerComplaint(user, selectedType, description);
            System.out.println("\n Complaint registered! Complaint ID: " + complaint.getComplaintId());
            
            // Ask for evidence upload
            System.out.print("\nDo you have evidence to upload? (y/n): ");
            String hasEvidence = scanner.nextLine();
            
            if (hasEvidence.equalsIgnoreCase("y")) {
                uploadEvidence(complaint.getComplaintId());
            }
            
            System.out.println("\n Complaint Registration Complete!");
            System.out.println(" Complaint ID: " + complaint.getComplaintId());
            System.out.println("Keep this ID for future reference.");
            
        } catch (CyberCrimeException e) {
            System.err.println(" Error: " + e.getMessage());
        }
    }
    
    private static void uploadEvidence(String complaintId) throws CyberCrimeException {
        System.out.println("\n UPLOAD EVIDENCE");
        System.out.println("Select evidence type:");
        
        Evidence.EvidenceType[] types = Evidence.EvidenceType.values();
        for (int i = 0; i < types.length; i++) {
            System.out.printf("%d. %s (%s)\n", i + 1, types[i].getDisplayName(), 
                types[i].getExtensions().isEmpty() ? "Any format" : types[i].getExtensions());
        }
        
        int typeChoice = getIntInput("Enter choice: ");
        if (typeChoice < 1 || typeChoice > types.length) {
            System.out.println(" Invalid choice!");
            return;
        }
        
        Evidence.EvidenceType selectedType = types[typeChoice - 1];
        
        System.out.print("Enter file path (or type 'text' for manual entry): ");
        String filePath = scanner.nextLine();
        
        String description;
        System.out.print("Enter description of this evidence: ");
        description = scanner.nextLine();
        
        if (filePath.equalsIgnoreCase("text")) {
            // Manual text entry
            System.out.println("Enter evidence text (type 'END' on new line to finish):");
            StringBuilder textContent = new StringBuilder();
            String line;
            while (!(line = scanner.nextLine()).equalsIgnoreCase("END")) {
                textContent.append(line).append("\n");
            }
            
            Evidence evidence = complaintService.addTextEvidence(complaintId, selectedType, 
                textContent.toString(), description);
            System.out.println("\n Text evidence uploaded successfully!");
            System.out.println("Evidence ID: " + evidence.getEvidenceId());
            
        } else {
            // File upload
            try {
                File file = new File(filePath);
                if (!file.exists()) {
                    System.out.println(" File not found!");
                    return;
                }
                
                // Read file as bytes
                byte[] fileData = java.nio.file.Files.readAllBytes(file.toPath());
                
                Evidence evidence = complaintService.addEvidence(complaintId, selectedType, 
                    file.getName(), fileData, description);
                System.out.println("\n Evidence uploaded successfully!");
                System.out.println("Evidence ID: " + evidence.getEvidenceId());
                System.out.println("File: " + evidence.getFileName());
                System.out.println("Size: " + evidence.getFileSizeFormatted());
                
            } catch (IOException e) {
                System.err.println(" Error reading file: " + e.getMessage());
            }
        }
        
        // Ask if more evidence
        System.out.print("\nUpload more evidence? (y/n): ");
        if (scanner.nextLine().equalsIgnoreCase("y")) {
            uploadEvidence(complaintId);
        }
    }
    
    private static User registerNewUser() {
        try {
            System.out.println("\n--- New User Registration ---");
            System.out.print("Full Name: ");
            String name = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Phone Number: ");
            String phone = scanner.nextLine();
            System.out.print("Create Password (min 6 chars): ");
            String password = scanner.nextLine();
            
            User user = authService.registerUser(name, email, phone, password);
            System.out.println("\n Registration Successful!");
            System.out.println("Your User ID: " + user.getUserId());
            System.out.println("Please note this ID for future logins.");
            return user;
        } catch (CyberCrimeException e) {
            System.err.println(" Registration Error: " + e.getMessage());
            return null;
        }
    }
    
    private static void viewCyberTips() {
        System.out.println("\n" + "=".repeat(40));
        System.out.println(" CYBER SAFETY TIPS");
        System.out.println("=".repeat(40));
        
        List<CyberTip> tips = tipService.getAllTips();
        Set<String> categories = tipService.getAllCategories();
        
        System.out.println("\nSelect category (or 0 for all):");
        List<String> categoryList = new ArrayList<>(categories);
        for (int i = 0; i < categoryList.size(); i++) {
            System.out.printf("%d. %s\n", i + 1, categoryList.get(i));
        }
        System.out.println("0. View All Tips");
        
        int choice = getIntInput("\nEnter choice: ");
        
        List<CyberTip> filteredTips;
        if (choice == 0) {
            filteredTips = tips;
        } else if (choice >= 1 && choice <= categoryList.size()) {
            String selectedCategory = categoryList.get(choice - 1);
            filteredTips = tipService.getTipsByCategory(selectedCategory);
        } else {
            System.out.println(" Invalid choice!");
            return;
        }
        
        if (filteredTips.isEmpty()) {
            System.out.println("No tips available.");
        } else {
            System.out.println("\n" + "=".repeat(50));
            for (CyberTip tip : filteredTips) {
                System.out.println(tip);
                System.out.println("-".repeat(50));
            }
        }
    }
    
    private static void giveFeedback() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println(" GIVE FEEDBACK");
            System.out.println("=".repeat(40));
            
            System.out.print("Enter your User ID: ");
            String userId = scanner.nextLine();
            
            User user = null;
            try {
                System.out.print("Enter password: ");
                String password = scanner.nextLine();
                user = authService.loginUser(userId, password);
            } catch (CyberCrimeException e) {
                System.out.println("Anonymous feedback will be recorded.");
            }
            
            System.out.println("\nHow would you rate our service?");
            System.out.println("1 - Very Poor");
            System.out.println("2 - Poor");
            System.out.println("3 - Average");
            System.out.println("4 - Good");
            System.out.println("5 - Excellent");
            
            int rating = getIntInput("Your rating: ");
            if (rating < 1 || rating > 5) {
                System.out.println(" Invalid rating!");
                return;
            }
            
            System.out.print("Your comments/suggestions: ");
            String comment = scanner.nextLine();
            
            Feedback feedback = feedbackService.submitFeedback(
                user != null ? user.getUserId() : "ANONYMOUS", rating, comment);
            
            System.out.println("\n Thank you for your feedback!");
            
        } catch (CyberCrimeException e) {
            System.err.println(" Error: " + e.getMessage());
        }
    }
    
    private static void officerLogin() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println(" POLICE OFFICER LOGIN");
            System.out.println("=".repeat(40));
            
            System.out.print("Username: ");
            String username = scanner.nextLine();
            System.out.print("Password: ");
            String password = scanner.nextLine();
            
            Officer officer = authService.loginOfficer(username, password);
            System.out.println("\n Welcome, Officer " + officer.getName() + "!");
            officerDashboard(officer);
            
        } catch (CyberCrimeException e) {
            System.err.println(" Login Error: " + e.getMessage());
        }
    }
    
    private static void officerDashboard(Officer officer) {
        while (true) {
            System.out.println("\n" + "-".repeat(40));
            System.out.println(" OFFICER DASHBOARD");
            System.out.println("-".repeat(40));
            System.out.println("1.  Update Complaint Status");
            System.out.println("2.  View All Complaints");
            System.out.println("3.  Search Complaint by ID");
            System.out.println("4.  View My Assigned Complaints");
            System.out.println("5.  Logout");
            
            int choice = getIntInput("Choose an option: ");
            
            try {
                switch (choice) {
                    case 1: updateComplaintStatus(officer); break;
                    case 2: viewAllComplaints(); break;
                    case 3: searchComplaintById(); break;
                    case 4: viewAssignedComplaints(officer); break;
                    case 5:
                        System.out.println("Logging out...");
                        return;
                    default: System.out.println(" Invalid option!");
                }
            } catch (CyberCrimeException e) {
                System.err.println(" Error: " + e.getMessage());
            }
        }
    }
    
    private static void updateComplaintStatus(Officer officer) throws CyberCrimeException {
        System.out.print("\nEnter Complaint ID: ");
        String complaintId = scanner.nextLine();
        
        Complaint complaint = complaintService.getComplaintById(complaintId);
        
        System.out.println("\nCurrent Status: " + complaint.getStatus().getDisplayName());
        System.out.println("\nSelect New Status:");
        Complaint.Status[] statuses = Complaint.Status.values();
        for (int i = 0; i < statuses.length; i++) {
            System.out.printf("%d. %s\n", i + 1, statuses[i].getDisplayName());
        }
        
        int statusChoice = getIntInput("Enter choice: ");
        if (statusChoice < 1 || statusChoice > statuses.length) {
            System.out.println(" Invalid choice!");
            return;
        }
        
        Complaint.Status newStatus = statuses[statusChoice - 1];
        System.out.print("Resolution Notes (optional): ");
        String notes = scanner.nextLine();
        
        complaintService.updateComplaintStatus(complaintId, newStatus, notes);
        
        if (complaint.getAssignedOfficerId() == null && newStatus != Complaint.Status.PENDING) {
            complaintService.assignComplaintToOfficer(complaintId, officer.getOfficerId());
            System.out.println(" Complaint assigned to you.");
        }
        
        System.out.println(" Status updated successfully!");
    }
    
    private static void viewAllComplaints() throws CyberCrimeException {
        List<Complaint> complaints = complaintService.getAllComplaints();
        
        if (complaints.isEmpty()) {
            System.out.println("\nNo complaints found.");
            return;
        }
        
        System.out.println("\n" + "=".repeat(90));
        System.out.printf("%-12s %-20s %-15s %-25s\n", 
            "Complaint ID", "Type", "Status", "Filed Date");
        System.out.println("=".repeat(90));
        
        for (Complaint c : complaints) {
            System.out.printf("%-12s %-20s %-15s %-25s\n",
                c.getComplaintId(),
                c.getType().getDisplayName(),
                c.getStatus().getDisplayName(),
                c.getFiledDate());
        }
        
        System.out.print("\nEnter complaint ID for details (or 0 to skip): ");
        String complaintId = scanner.nextLine();
        
        if (!complaintId.equals("0")) {
            try {
                Complaint complaint = complaintService.getComplaintById(complaintId);
                displayComplaintDetails(complaint);
            } catch (CyberCrimeException e) {
                System.err.println(e.getMessage());
            }
        }
    }
    
    private static void searchComplaintById() throws CyberCrimeException {
        System.out.print("\nEnter Complaint ID: ");
        String complaintId = scanner.nextLine();
        Complaint complaint = complaintService.getComplaintById(complaintId);
        displayComplaintDetails(complaint);
    }
    
    private static void viewAssignedComplaints(Officer officer) throws CyberCrimeException {
        List<Complaint> assignedComplaints = complaintService.getComplaintsByOfficer(officer.getOfficerId());
        
        if (assignedComplaints.isEmpty()) {
            System.out.println("\nNo complaints assigned to you.");
            return;
        }
        
        System.out.println("\n" + "=".repeat(80));
        System.out.println(" YOUR ASSIGNED COMPLAINTS");
        System.out.println("=".repeat(80));
        System.out.printf("%-12s %-20s %-15s\n", "Complaint ID", "Type", "Status");
        System.out.println("-".repeat(80));
        
        for (Complaint c : assignedComplaints) {
            System.out.printf("%-12s %-20s %-15s\n",
                c.getComplaintId(),
                c.getType().getDisplayName(),
                c.getStatus().getDisplayName());
        }
    }
    
    private static void displayComplaintDetails(Complaint complaint) throws CyberCrimeException {
        System.out.println("\n" + "=".repeat(50));
        System.out.println(" COMPLAINT DETAILS");
        System.out.println("=".repeat(50));
        System.out.println("Complaint ID: " + complaint.getComplaintId());
        System.out.println("User ID: " + complaint.getUserId());
        System.out.println("Type: " + complaint.getType().getDisplayName());
        System.out.println("Status: " + complaint.getStatus().getDisplayName());
        System.out.println("Filed Date: " + complaint.getFiledDate());
        System.out.println("Description: " + complaint.getDescription());
        System.out.println("Assigned Officer: " + 
            (complaint.getAssignedOfficerId() != null ? complaint.getAssignedOfficerId() : "Not assigned"));
        System.out.println("Resolution Notes: " + 
            (complaint.getResolutionNotes().isEmpty() ? "None" : complaint.getResolutionNotes()));
        
        // Display evidence
        List<Evidence> evidences = complaintService.getEvidencesByComplaint(complaint.getComplaintId());
        if (!evidences.isEmpty()) {
            System.out.println("\n EVIDENCE (" + evidences.size() + " files):");
            for (int i = 0; i < evidences.size(); i++) {
                Evidence e = evidences.get(i);
                System.out.printf("   %d. %s - %s (%s)\n", i + 1, 
                    e.getType().getDisplayName(), e.getFileName(), e.getFileSizeFormatted());
                System.out.println("      Description: " + e.getDescription());
            }
            
            System.out.print("\nView evidence details? (y/n): ");
            if (scanner.nextLine().equalsIgnoreCase("y")) {
                System.out.print("Enter evidence number: ");
                int evNum = getIntInput("");
                if (evNum >= 1 && evNum <= evidences.size()) {
                    Evidence ev = evidences.get(evNum - 1);
                    System.out.println("\n--- Evidence Details ---");
                    System.out.println("File: " + ev.getFileName());
                    System.out.println("Type: " + ev.getType().getDisplayName());
                    System.out.println("Size: " + ev.getFileSizeFormatted());
                    System.out.println("Uploaded: " + ev.getUploadDate());
                    System.out.println("Description: " + ev.getDescription());
                    System.out.println("Path: " + ev.getFilePath());
                }
            }
        }
    }
    
    private static void adminLogin() {
        try {
            System.out.println("\n" + "=".repeat(40));
            System.out.println(" ADMIN LOGIN");
            System.out.println("=".repeat(40));
            
            System.out.print("Username: ");
            String username = scanner.nextLine();
            System.out.print("Password: ");
            String password = scanner.nextLine();
            
            Officer admin = authService.loginOfficer(username, password);
            
            if (!admin.getUsername().equals("admin")) {
                System.out.println(" Access denied. Admin privileges required.");
                return;
            }
            
            System.out.println("\n Welcome, Administrator!");
            adminDashboard();
            
        } catch (CyberCrimeException e) {
            System.err.println(" Login Error: " + e.getMessage());
        }
    }
    
    private static void adminDashboard() {
        while (true) {
            System.out.println("\n" + "-".repeat(40));
            System.out.println("🔧 ADMIN DASHBOARD");
            System.out.println("-".repeat(40));
            System.out.println("1.  Add New Officer");
            System.out.println("2.  View All Officers");
            System.out.println("3.  Delete Officer");
            System.out.println("4.  View Complaint Statistics");
            System.out.println("5.  Assign Complaint to Officer");
            System.out.println("6.  View All User Feedbacks");
            System.out.println("7.  Logout");
            
            int choice = getIntInput("Choose an option: ");
            
            try {
                switch (choice) {
                    case 1: addNewOfficer(); break;
                    case 2: viewAllOfficers(); break;
                    case 3: deleteOfficer(); break;
                    case 4: statisticsService.displayStatistics(); break;
                    case 5: assignComplaintToOfficer(); break;
                    case 6: viewAllFeedbacks(); break;
                    case 7:
                        System.out.println("Logging out...");
                        return;
                    default: System.out.println("❌ Invalid option!");
                }
            } catch (CyberCrimeException e) {
                System.err.println("❌ Error: " + e.getMessage());
            }
        }
    }
    
    private static void addNewOfficer() throws CyberCrimeException {
        System.out.println("\n--- Add New Police Officer ---");
        String officerId = "O" + System.currentTimeMillis();
        System.out.print("Full Name: ");
        String name = scanner.nextLine();
        System.out.print("Badge Number: ");
        String badgeNumber = scanner.nextLine();
        System.out.print("Department: ");
        String department = scanner.nextLine();
        System.out.print("Rank: ");
        String rank = scanner.nextLine();
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        
        Officer officer = new Officer(officerId, name, badgeNumber, 
            department, username, password, rank);
        authService.addOfficer(officer);
        
        System.out.println("\nOfficer added successfully!");
        System.out.println("Officer ID: " + officerId);
    }
    
    private static void viewAllOfficers() {
        List<Officer> officers = authService.getAllOfficers();
        
        if (officers.isEmpty()) {
            System.out.println("\nNo officers found.");
            return;
        }
        
        System.out.println("\n" + "=".repeat(90));
        System.out.printf("%-12s %-20s %-15s %-20s %-10s\n", 
            "Badge", "Name", "Department", "Username", "Rank");
        System.out.println("=".repeat(90));
        
        for (Officer o : officers) {
            System.out.printf("%-12s %-20s %-15s %-20s %-10s\n",
                o.getBadgeNumber(),
                o.getName(),
                o.getDepartment(),
                o.getUsername(),
                o.getRank());
        }
    }
    
    private static void deleteOfficer() throws CyberCrimeException {
        System.out.print("\nEnter username of officer to delete: ");
        String username = scanner.nextLine();
        authService.deleteOfficer(username);
        System.out.println("Officer deleted successfully!");
    }
    
    private static void assignComplaintToOfficer() throws CyberCrimeException {
        System.out.print("\nEnter Complaint ID: ");
        String complaintId = scanner.nextLine();
        
        Complaint complaint = complaintService.getComplaintById(complaintId);
        
        System.out.println("Complaint: " + complaint.getType().getDisplayName());
        System.out.println("Current Status: " + complaint.getStatus().getDisplayName());
        
        List<Officer> officers = authService.getAllOfficers();
        System.out.println("\nAvailable Officers:");
        for (Officer o : officers) {
            System.out.println("- " + o.getUsername() + " (" + o.getName() + ")");
        }
        
        System.out.print("\nEnter Officer Username to assign: ");
        String officerUsername = scanner.nextLine();
        
        Officer officer = authService.getOfficerByUsername(officerUsername);
        if (officer == null) {
            throw new CyberCrimeException("Officer not found!");
        }
        
        complaintService.assignComplaintToOfficer(complaintId, officer.getOfficerId());
        System.out.println("\nComplaint assigned to Officer " + officer.getName());
    }
    
    private static void viewAllFeedbacks() {
        List<Feedback> feedbacks = feedbackService.getAllFeedbacks();
        
        if (feedbacks.isEmpty()) {
            System.out.println("\nNo feedbacks received yet.");
            return;
        }
        
        System.out.println("\n" + "=".repeat(70));
        System.out.println("USER FEEDBACKS");
        System.out.println("=".repeat(70));
        
        for (Feedback f : feedbacks) {
            System.out.printf("\nUser: %s\nRating: %d/5\nDate: %s\nComment: %s\n",
                f.getUserId(),
                f.getRating(),
                f.getSubmittedDate(),
                f.getComment());
            System.out.println("-".repeat(50));
        }
        
        double avgRating = feedbackService.getAverageRating();
        System.out.printf("\nAverage Rating: %.2f/5\n", avgRating);
    }
    
    private static int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}