package cybercrime.services;

import cybercrime.exceptions.CyberCrimeException;
import cybercrime.models.*;
import java.util.*;

public class ComplaintService {
    private Map<String, Complaint> complaints;
    private Map<String, Evidence> evidences;
    private FileStorageService storageService;
    
    public ComplaintService(FileStorageService storageService) throws CyberCrimeException {
        this.storageService = storageService;
        this.complaints = new LinkedHashMap<>();
        this.evidences = new HashMap<>();
        loadComplaints();
        loadEvidences();
    }
    
    private void loadComplaints() throws CyberCrimeException {
        complaints.putAll(storageService.loadComplaints());
    }
    
    private void loadEvidences() throws CyberCrimeException {
        evidences.putAll(storageService.loadEvidences());
    }
    
    public Complaint registerComplaint(User user, Complaint.ComplaintType type, 
                                       String description) 
            throws CyberCrimeException {
        if (description == null || description.trim().isEmpty()) {
            throw new CyberCrimeException("Description cannot be empty");
        }
        if (description.length() < 10) {
            throw new CyberCrimeException("Description must be at least 10 characters");
        }
        
        String complaintId = "C" + System.currentTimeMillis();
        Complaint complaint = new Complaint(complaintId, user.getUserId(), 
            type, description, null);
        complaints.put(complaintId, complaint);
        saveComplaints();
        
        return complaint;
    }
    
    public Evidence addEvidence(String complaintId, Evidence.EvidenceType type, 
                                String fileName, byte[] fileData, String description) 
            throws CyberCrimeException {
        Complaint complaint = complaints.get(complaintId);
        if (complaint == null) {
            throw new CyberCrimeException("Complaint not found");
        }
        
        String evidenceId = "E" + System.currentTimeMillis();
        String filePath = storageService.saveEvidenceFile(complaintId, fileName, fileData);
        long fileSize = fileData.length;
        
        Evidence evidence = new Evidence(evidenceId, complaintId, type, fileName, 
            filePath, description, fileSize);
        evidences.put(evidenceId, evidence);
        saveEvidences();
        
        // Update complaint with evidence path
        complaint.setEvidencePath(filePath);
        saveComplaints();
        
        return evidence;
    }
    
    public Evidence addTextEvidence(String complaintId, Evidence.EvidenceType type, 
                                    String textContent, String description) 
            throws CyberCrimeException {
        Complaint complaint = complaints.get(complaintId);
        if (complaint == null) {
            throw new CyberCrimeException("Complaint not found");
        }
        
        String evidenceId = "E" + System.currentTimeMillis();
        String filePath = storageService.saveTextEvidence(complaintId, textContent);
        
        Evidence evidence = new Evidence(evidenceId, complaintId, type, 
            "text_evidence.txt", filePath, description, textContent.length());
        evidences.put(evidenceId, evidence);
        saveEvidences();
        
        // Update complaint with evidence path
        complaint.setEvidencePath(filePath);
        saveComplaints();
        
        return evidence;
    }
    
    public List<Evidence> getEvidencesByComplaint(String complaintId) {
        List<Evidence> complaintEvidences = new ArrayList<>();
        for (Evidence evidence : evidences.values()) {
            if (evidence.getComplaintId().equals(complaintId)) {
                complaintEvidences.add(evidence);
            }
        }
        return complaintEvidences;
    }
    
    public Evidence getEvidenceById(String evidenceId) throws CyberCrimeException {
        Evidence evidence = evidences.get(evidenceId);
        if (evidence == null) {
            throw new CyberCrimeException("Evidence not found");
        }
        return evidence;
    }
    
    public void updateComplaintStatus(String complaintId, Complaint.Status newStatus, 
                                      String resolutionNotes) throws CyberCrimeException {
        Complaint complaint = complaints.get(complaintId);
        if (complaint == null) {
            throw new CyberCrimeException("Complaint not found");
        }
        
        complaint.setStatus(newStatus);
        if (resolutionNotes != null && !resolutionNotes.trim().isEmpty()) {
            complaint.setResolutionNotes(resolutionNotes);
        }
        
        saveComplaints();
    }
    
    public void assignComplaintToOfficer(String complaintId, String officerId) 
            throws CyberCrimeException {
        Complaint complaint = complaints.get(complaintId);
        if (complaint == null) {
            throw new CyberCrimeException("Complaint not found");
        }
        
        complaint.setAssignedOfficerId(officerId);
        if (complaint.getStatus() == Complaint.Status.PENDING) {
            complaint.setStatus(Complaint.Status.UNDER_REVIEW);
        }
        
        saveComplaints();
    }
    
    public List<Complaint> getAllComplaints() {
        List<Complaint> complaintList = new ArrayList<>(complaints.values());
        Collections.sort(complaintList, (c1, c2) -> c2.getFiledDate().compareTo(c1.getFiledDate()));
        return complaintList;
    }
    
    public List<Complaint> getComplaintsByUser(String userId) {
        List<Complaint> userComplaints = new ArrayList<>();
        for (Complaint complaint : complaints.values()) {
            if (complaint.getUserId().equals(userId)) {
                userComplaints.add(complaint);
            }
        }
        return userComplaints;
    }
    
    public List<Complaint> getComplaintsByOfficer(String officerId) {
        List<Complaint> officerComplaints = new ArrayList<>();
        for (Complaint complaint : complaints.values()) {
            if (officerId.equals(complaint.getAssignedOfficerId())) {
                officerComplaints.add(complaint);
            }
        }
        return officerComplaints;
    }
    
    public Complaint getComplaintById(String complaintId) throws CyberCrimeException {
        Complaint complaint = complaints.get(complaintId);
        if (complaint == null) {
            throw new CyberCrimeException("Complaint not found with ID: " + complaintId);
        }
        return complaint;
    }
    
    public Map<Complaint.ComplaintType, Integer> getComplaintStatisticsByType() {
        Map<Complaint.ComplaintType, Integer> stats = new TreeMap<>();
        for (Complaint complaint : complaints.values()) {
            Complaint.ComplaintType type = complaint.getType();
            stats.put(type, stats.getOrDefault(type, 0) + 1);
        }
        return stats;
    }
    
    public Map<Complaint.Status, Integer> getComplaintStatisticsByStatus() {
        Map<Complaint.Status, Integer> stats = new HashMap<>();
        for (Complaint complaint : complaints.values()) {
            Complaint.Status status = complaint.getStatus();
            stats.put(status, stats.getOrDefault(status, 0) + 1);
        }
        return stats;
    }
    
    private void saveComplaints() throws CyberCrimeException {
        storageService.saveComplaints(complaints);
    }
    
    private void saveEvidences() throws CyberCrimeException {
        storageService.saveEvidences(evidences);
    }
}