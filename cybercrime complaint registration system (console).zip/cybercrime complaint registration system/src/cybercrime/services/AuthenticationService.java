package cybercrime.services;

import cybercrime.exceptions.CyberCrimeException;
import cybercrime.models.*;
import java.util.*;

public class AuthenticationService {
    private Map<String, User> users;
    private Map<String, Officer> officers;
    private FileStorageService storageService;
    
    public AuthenticationService(FileStorageService storageService) throws CyberCrimeException {
        this.storageService = storageService;
        this.users = new HashMap<>();
        this.officers = new HashMap<>();
        loadData();
    }
    
    private void loadData() throws CyberCrimeException {
        users.putAll(storageService.loadUsers());
        officers.putAll(storageService.loadOfficers());
        
        if (!officers.containsKey("admin")) {
            Officer admin = new Officer("ADMIN001", "System Administrator", 
                "ADMIN001", "Administration", "admin", "admin123", "Administrator");
            officers.put("admin", admin);
            saveOfficers();
        }
    }
    
    public User registerUser(String name, String email, String phone, String password) 
            throws CyberCrimeException {
        String userId = "U" + System.currentTimeMillis();
        
        if (name == null || name.trim().isEmpty()) {
            throw new CyberCrimeException("Name cannot be empty");
        }
        if (!email.contains("@") || !email.contains(".")) {
            throw new CyberCrimeException("Invalid email format");
        }
        if (phone.length() < 10) {
            throw new CyberCrimeException("Invalid phone number");
        }
        if (password.length() < 6) {
            throw new CyberCrimeException("Password must be at least 6 characters");
        }
        
        User user = new User(userId, name, email, phone, password);
        users.put(userId, user);
        saveUsers();
        return user;
    }
    
    public User loginUser(String userId, String password) throws CyberCrimeException {
        User user = users.get(userId);
        if (user == null) {
            throw new CyberCrimeException("User not found");
        }
        if (!user.getPassword().equals(password)) {
            throw new CyberCrimeException("Invalid password");
        }
        return user;
    }
    
    public Officer loginOfficer(String username, String password) throws CyberCrimeException {
        Officer officer = officers.get(username);
        if (officer == null) {
            throw new CyberCrimeException("Officer not found");
        }
        if (!officer.getPassword().equals(password)) {
            throw new CyberCrimeException("Invalid password");
        }
        return officer;
    }
    
    public void addOfficer(Officer officer) throws CyberCrimeException {
        if (officers.containsKey(officer.getUsername())) {
            throw new CyberCrimeException("Username already exists");
        }
        officers.put(officer.getUsername(), officer);
        saveOfficers();
    }
    
    public void deleteOfficer(String username) throws CyberCrimeException {
        if (!officers.containsKey(username)) {
            throw new CyberCrimeException("Officer not found");
        }
        if (username.equals("admin")) {
            throw new CyberCrimeException("Cannot delete admin account");
        }
        officers.remove(username);
        saveOfficers();
    }
    
    public List<Officer> getAllOfficers() {
        List<Officer> officerList = new ArrayList<>();
        for (Officer officer : officers.values()) {
            if (officer.isActive()) {
                officerList.add(officer);
            }
        }
        Collections.sort(officerList, (o1, o2) -> o1.getName().compareTo(o2.getName()));
        return officerList;
    }
    
    public Officer getOfficerByUsername(String username) {
        return officers.get(username);
    }
    
    private void saveUsers() throws CyberCrimeException {
        storageService.saveUsers(users);
    }
    
    private void saveOfficers() throws CyberCrimeException {
        storageService.saveOfficers(officers);
    }
}