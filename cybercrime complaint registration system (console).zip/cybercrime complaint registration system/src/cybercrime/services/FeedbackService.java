package cybercrime.services;

import cybercrime.exceptions.CyberCrimeException;
import cybercrime.models.Feedback;
import java.util.*;

public class FeedbackService {
    private Map<String, Feedback> feedbacks;
    private FileStorageService storageService;
    
    public FeedbackService(FileStorageService storageService) throws CyberCrimeException {
        this.storageService = storageService;
        this.feedbacks = new HashMap<>();
        loadFeedbacks();
    }
    
    private void loadFeedbacks() throws CyberCrimeException {
        feedbacks.putAll(storageService.loadFeedbacks());
    }
    
    public Feedback submitFeedback(String userId, int rating, String comment) 
            throws CyberCrimeException {
        if (rating < 1 || rating > 5) {
            throw new CyberCrimeException("Rating must be between 1 and 5");
        }
        
        String feedbackId = "FB" + System.currentTimeMillis();
        Feedback feedback = new Feedback(feedbackId, userId, rating, comment);
        feedbacks.put(feedbackId, feedback);
        saveFeedbacks();
        
        return feedback;
    }
    
    public List<Feedback> getAllFeedbacks() {
        List<Feedback> feedbackList = new ArrayList<>(feedbacks.values());
        Collections.sort(feedbackList, (f1, f2) -> f2.getSubmittedDate().compareTo(f1.getSubmittedDate()));
        return feedbackList;
    }
    
    public double getAverageRating() {
        if (feedbacks.isEmpty()) return 0.0;
        int total = 0;
        for (Feedback feedback : feedbacks.values()) {
            total += feedback.getRating();
        }
        return (double) total / feedbacks.size();
    }
    
    private void saveFeedbacks() throws CyberCrimeException {
        storageService.saveFeedbacks(feedbacks);
    }
}