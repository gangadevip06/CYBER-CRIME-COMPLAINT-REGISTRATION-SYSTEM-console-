package cybercrime.services;

import cybercrime.exceptions.CyberCrimeException;
import cybercrime.models.CyberTip;
import java.util.*;

public class CyberTipService {
    private List<CyberTip> tips;
    private FileStorageService storageService;
    
    public CyberTipService(FileStorageService storageService) throws CyberCrimeException {
        this.storageService = storageService;
        this.tips = new ArrayList<>();
        loadTips();
        
        if (tips.isEmpty()) {
            initializeTips();
        }
    }
    
    private void loadTips() throws CyberCrimeException {
        tips.addAll(storageService.loadTips());
    }
    
    private void initializeTips() throws CyberCrimeException {
        List<CyberTip> tipList = new ArrayList<>();
        tipList.add(new CyberTip(" Strong Passwords", 
            "Use a mix of uppercase, lowercase, numbers, and special characters. Never reuse passwords.", 
            "Password Security"));
        tipList.add(new CyberTip(" Beware of Phishing", 
            "Never click on suspicious links in emails. Verify the sender's email address before providing personal information.", 
            "Email Safety"));
        tipList.add(new CyberTip(" Two-Factor Authentication", 
            "Enable 2FA on all your important accounts for an extra layer of security.", 
            "Account Security"));
        tipList.add(new CyberTip(" Secure Your Wi-Fi", 
            "Use WPA3 encryption, change default router passwords, and disable WPS feature.", 
            "Network Security"));
        tipList.add(new CyberTip(" Social Media Privacy", 
            "Review privacy settings regularly. Avoid sharing personal information publicly.", 
            "Social Media Safety"));
        tipList.add(new CyberTip(" Update Regularly", 
            "Keep your OS, apps, and antivirus updated. Security patches fix vulnerabilities.", 
            "System Security"));
        tipList.add(new CyberTip(" Safe Online Shopping", 
            "Shop only on secure websites (https://). Use credit cards for better fraud protection.", 
            "Online Shopping"));
        tipList.add(new CyberTip(" Backup Your Data", 
            "Regularly backup important files to external drive or cloud storage.", 
            "Data Protection"));
        
        tips.addAll(tipList);
        saveTips();
    }
    
    public List<CyberTip> getAllTips() {
        return tips;
    }
    
    public List<CyberTip> getTipsByCategory(String category) {
        List<CyberTip> categoryTips = new ArrayList<>();
        for (CyberTip tip : tips) {
            if (tip.getCategory().equalsIgnoreCase(category)) {
                categoryTips.add(tip);
            }
        }
        return categoryTips;
    }
    
    public Set<String> getAllCategories() {
        Set<String> categories = new TreeSet<>();
        for (CyberTip tip : tips) {
            categories.add(tip.getCategory());
        }
        return categories;
    }
    
    private void saveTips() throws CyberCrimeException {
        storageService.saveTips(tips);
    }
}