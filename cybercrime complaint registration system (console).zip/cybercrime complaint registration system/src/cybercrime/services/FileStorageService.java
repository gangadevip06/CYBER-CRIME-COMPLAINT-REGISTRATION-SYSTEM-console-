package cybercrime.services;

import cybercrime.exceptions.CyberCrimeException;
import cybercrime.models.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class FileStorageService {
    private static final String DATA_DIR = "data/";
    private static final String USERS_FILE = DATA_DIR + "users.txt";
    private static final String OFFICERS_FILE = DATA_DIR + "officers.txt";
    private static final String COMPLAINTS_FILE = DATA_DIR + "complaints.txt";
    private static final String FEEDBACKS_FILE = DATA_DIR + "feedbacks.txt";
    private static final String TIPS_FILE = DATA_DIR + "tips.txt";
    private static final String EVIDENCE_FILE = DATA_DIR + "evidence.txt";
    private static final String EVIDENCE_DIR = DATA_DIR + "evidence/";
    
    public FileStorageService() {
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            dataDir.mkdirs();
        }
        
        File evidenceDir = new File(EVIDENCE_DIR);
        if (!evidenceDir.exists()) {
            evidenceDir.mkdirs();
        }
    }
    
    // User operations
    public void saveUsers(Map<String, User> users) throws CyberCrimeException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users.values()) {
                writer.write(user.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving users", e);
        }
    }
    
    public Map<String, User> loadUsers() throws CyberCrimeException {
        Map<String, User> users = new HashMap<>();
        File file = new File(USERS_FILE);
        if (!file.exists()) return users;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    User user = User.fromFileString(line);
                    users.put(user.getUserId(), user);
                }
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error loading users", e);
        }
        return users;
    }
    
    // Officer operations
    public void saveOfficers(Map<String, Officer> officers) throws CyberCrimeException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(OFFICERS_FILE))) {
            for (Officer officer : officers.values()) {
                writer.write(officer.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving officers", e);
        }
    }
    
    public Map<String, Officer> loadOfficers() throws CyberCrimeException {
        Map<String, Officer> officers = new HashMap<>();
        File file = new File(OFFICERS_FILE);
        if (!file.exists()) return officers;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    Officer officer = Officer.fromFileString(line);
                    officers.put(officer.getUsername(), officer);
                }
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error loading officers", e);
        }
        return officers;
    }
    
    // Complaint operations
    public void saveComplaints(Map<String, Complaint> complaints) throws CyberCrimeException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(COMPLAINTS_FILE))) {
            for (Complaint complaint : complaints.values()) {
                writer.write(complaint.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving complaints", e);
        }
    }
    
    public Map<String, Complaint> loadComplaints() throws CyberCrimeException {
        Map<String, Complaint> complaints = new HashMap<>();
        File file = new File(COMPLAINTS_FILE);
        if (!file.exists()) return complaints;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    Complaint complaint = Complaint.fromFileString(line);
                    complaints.put(complaint.getComplaintId(), complaint);
                }
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error loading complaints", e);
        }
        return complaints;
    }
    
    // Feedback operations
    public void saveFeedbacks(Map<String, Feedback> feedbacks) throws CyberCrimeException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FEEDBACKS_FILE))) {
            for (Feedback feedback : feedbacks.values()) {
                writer.write(feedback.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving feedbacks", e);
        }
    }
    
    public Map<String, Feedback> loadFeedbacks() throws CyberCrimeException {
        Map<String, Feedback> feedbacks = new HashMap<>();
        File file = new File(FEEDBACKS_FILE);
        if (!file.exists()) return feedbacks;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    Feedback feedback = Feedback.fromFileString(line);
                    feedbacks.put(feedback.getFeedbackId(), feedback);
                }
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error loading feedbacks", e);
        }
        return feedbacks;
    }
    
    // Tips operations
    public void saveTips(List<CyberTip> tips) throws CyberCrimeException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TIPS_FILE))) {
            for (CyberTip tip : tips) {
                writer.write(tip.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving tips", e);
        }
    }
    
    public List<CyberTip> loadTips() throws CyberCrimeException {
        List<CyberTip> tips = new ArrayList<>();
        File file = new File(TIPS_FILE);
        if (!file.exists()) return tips;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    tips.add(CyberTip.fromFileString(line));
                }
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error loading tips", e);
        }
        return tips;
    }
    
    // Evidence operations
    public void saveEvidences(Map<String, Evidence> evidences) throws CyberCrimeException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(EVIDENCE_FILE))) {
            for (Evidence evidence : evidences.values()) {
                writer.write(evidence.toFileString());
                writer.newLine();
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving evidences", e);
        }
    }
    
    public Map<String, Evidence> loadEvidences() throws CyberCrimeException {
        Map<String, Evidence> evidences = new HashMap<>();
        File file = new File(EVIDENCE_FILE);
        if (!file.exists()) return evidences;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    Evidence evidence = Evidence.fromFileString(line);
                    evidences.put(evidence.getEvidenceId(), evidence);
                }
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error loading evidences", e);
        }
        return evidences;
    }
    
    // Save evidence file (for screenshots, images, documents, etc.)
    public String saveEvidenceFile(String complaintId, String fileName, byte[] fileData) 
            throws CyberCrimeException {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String safeFileName = fileName.replaceAll("[^a-zA-Z0-9.-]", "_");
        String filePath = EVIDENCE_DIR + complaintId + "_" + timestamp + "_" + safeFileName;
        
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            fos.write(fileData);
            return filePath;
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving evidence file: " + fileName, e);
        }
    }
    
    // Save text evidence
    public String saveTextEvidence(String complaintId, String content) throws CyberCrimeException {
        String timestamp = String.valueOf(System.currentTimeMillis());
        String filePath = EVIDENCE_DIR + complaintId + "_" + timestamp + "_evidence.txt";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
            return filePath;
        } catch (IOException e) {
            throw new CyberCrimeException("Error saving text evidence", e);
        }
    }
    
    // Read evidence file
    public byte[] readEvidenceFile(String filePath) throws CyberCrimeException {
        try {
            return Files.readAllBytes(Paths.get(filePath));
        } catch (IOException e) {
            throw new CyberCrimeException("Error reading evidence file", e);
        }
    }
    
    public String readTextEvidence(String filePath) throws CyberCrimeException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            throw new CyberCrimeException("Error reading text evidence", e);
        }
        return content.toString();
    }
    
    public String getFileExtension(String fileName) {
        int lastDot = fileName.lastIndexOf(".");
        if (lastDot > 0) {
            return fileName.substring(lastDot + 1).toLowerCase();
        }
        return "";
    }
    
    public boolean isImageFile(String fileName) {
        String ext = getFileExtension(fileName);
        return ext.equals("jpg") || ext.equals("jpeg") || ext.equals("png") || 
               ext.equals("gif") || ext.equals("bmp");
    }
    
    public boolean isDocumentFile(String fileName) {
        String ext = getFileExtension(fileName);
        return ext.equals("pdf") || ext.equals("doc") || ext.equals("docx") || 
               ext.equals("txt");
    }
}