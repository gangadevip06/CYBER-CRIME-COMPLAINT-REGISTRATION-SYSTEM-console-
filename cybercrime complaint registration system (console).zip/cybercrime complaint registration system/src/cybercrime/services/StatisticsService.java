package cybercrime.services;

import cybercrime.models.*;
import java.util.*;

public class StatisticsService {
    private ComplaintService complaintService;
    private FeedbackService feedbackService;
    
    public StatisticsService(ComplaintService complaintService, 
                             FeedbackService feedbackService) {
        this.complaintService = complaintService;
        this.feedbackService = feedbackService;
    }
    
    public void displayStatistics() {
        List<Complaint> complaints = complaintService.getAllComplaints();
        List<Feedback> feedbacks = feedbackService.getAllFeedbacks();
        
        System.out.println("\n" + "=".repeat(60));
        System.out.println(" COMPLAINT STATISTICS");
        System.out.println("=".repeat(60));
        
        System.out.printf("\n Total Complaints Filed: %d\n", complaints.size());
        
        System.out.println("\n By Complaint Type:");
        Map<Complaint.ComplaintType, Integer> typeStats = complaintService.getComplaintStatisticsByType();
        for (Map.Entry<Complaint.ComplaintType, Integer> entry : typeStats.entrySet()) {
            System.out.printf("   • %-20s: %d\n", entry.getKey().getDisplayName(), entry.getValue());
        }
        
        System.out.println("\n By Status:");
        Map<Complaint.Status, Integer> statusStats = complaintService.getComplaintStatisticsByStatus();
        for (Map.Entry<Complaint.Status, Integer> entry : statusStats.entrySet()) {
            System.out.printf("   • %-20s: %d\n", entry.getKey().getDisplayName(), entry.getValue());
        }
        
        int resolvedCount = statusStats.getOrDefault(Complaint.Status.RESOLVED, 0);
        double resolutionRate = complaints.isEmpty() ? 0 : (resolvedCount * 100.0 / complaints.size());
        System.out.printf("\n Resolution Rate: %.2f%%\n", resolutionRate);
        
        if (!feedbacks.isEmpty()) {
            double avgRating = feedbackService.getAverageRating();
            System.out.printf("\n Average User Rating: %.2f/5 (from %d reviews)\n", 
                avgRating, feedbacks.size());
        }
        
        System.out.println("=".repeat(60));
    }
}